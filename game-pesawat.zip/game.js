// Canvas Setup
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Player (pesawat)
let player = {
    x: 180,
    y: 500,
    width: 40,
    height: 40,
    speed: 5
};

// Awan (obstacle)
let clouds = [];
let cloudSpeed = 2;

// Score
let score = 0;
let gameRunning = false;
let gameLoop;

// Input movement
let keys = {};

document.addEventListener("keydown", e => {
    keys[e.key] = true;
});
document.addEventListener("keyup", e => {
    keys[e.key] = false;
});

// Fungsi gambar pesawat
function drawPlayer() {
    ctx.fillStyle = "red";
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

// Fungsi gambar awan
function drawCloud(cloud) {
    ctx.fillStyle = "white";
    ctx.fillRect(cloud.x, cloud.y, cloud.width, cloud.height);
}

// Spawn awan baru
function spawnCloud() {
    let cloud = {
        x: Math.random() * 360,
        y: -40,
        width: 40,
        height: 40
    };
    clouds.push(cloud);
}

// Gerak awan
function updateClouds() {
    for (let c of clouds) {
        c.y += cloudSpeed;
    }

    // Hapus awan keluar layar
    clouds = clouds.filter(c => c.y < 650);
}

// Deteksi tabrakan
function detectCollision() {
    for (let cloud of clouds) {
        if (
            player.x < cloud.x + cloud.width &&
            player.x + player.width > cloud.x &&
            player.y < cloud.y + cloud.height &&
            player.y + player.height > cloud.y
        ) {
            stopGame();
            alert("Game Over! Score: " + score);
        }
    }
}

// Update gerakan pesawat
function updatePlayer() {
    if (keys["ArrowLeft"] && player.x > 0) player.x -= player.speed;
    if (keys["ArrowRight"] && player.x < canvas.width - player.width) player.x += player.speed;
}

// Loop utama game
function gameUpdate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    updatePlayer();
    updateClouds();
    detectCollision();

    drawPlayer();
    clouds.forEach(drawCloud);

    score++;
    document.getElementById("scoreDisplay").innerText = "Score: " + score;

    if (Math.random() < 0.03) spawnCloud();
}

// Start game
function startGame() {
    if (!gameRunning) {
        gameRunning = true;
        gameLoop = setInterval(gameUpdate, 20);
    }
}

// Pause game
function pauseGame() {
    clearInterval(gameLoop);
    gameRunning = false;
}

// Reset game
function resetGame() {
    pauseGame();
    player.x = 180;
    player.y = 500;
    clouds = [];
    score = 0;
    document.getElementById("scoreDisplay").innerText = "Score: 0";
}

// Event tombol
document.getElementById("playBtn").onclick = startGame;
document.getElementById("pauseBtn").onclick = pauseGame;
document.getElementById("resetBtn").onclick = resetGame;
